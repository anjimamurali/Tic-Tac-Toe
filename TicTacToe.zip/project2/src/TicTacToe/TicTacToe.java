package TicTacToe;
import java.util.Scanner;

public class TicTacToe {
	    static char[][] board = new char[3][3];
	    static Scanner scanner = new Scanner(System.in);

	    public static void main(String[] args) {
	        System.out.println("Welcome to Tic-Tac-Toe!");
	        boolean playAgain;

	        do {
	            resetBoard();
	            playGame();
	            System.out.print("Play again? (yes/no): ");
	            playAgain = scanner.next().equalsIgnoreCase("yes");
	        } while (playAgain);

	        System.out.println("Thanks for playing!");
	    }

	    static void playGame() {
	        char currentPlayer = 'X';
	        int moves = 0;
	        boolean gameEnded = false;

	        while (!gameEnded && moves < 9) {
	            printBoard();
	            System.out.println("Player " + currentPlayer + "'s turn.");
	            int row, col;

	            while (true) {
	                System.out.print("Enter row (0, 1, 2): ");
	                row = scanner.nextInt();
	                System.out.print("Enter column (0, 1, 2): ");
	                col = scanner.nextInt();

	                if (row >= 0 && row < 3 && col >= 0 && col < 3 && board[row][col] == ' ') {
	                    board[row][col] = currentPlayer;
	                    break;
	                } else {
	                    System.out.println("Invalid move. Try again.");
	                }
	            }

	            moves++;
	            if (checkWin(currentPlayer)) {
	                printBoard();
	                System.out.println("Player " + currentPlayer + " wins!");
	                gameEnded = true;
	            } else if (moves == 9) {
	                printBoard();
	                System.out.println("It's a draw!");
	            } else {
	                currentPlayer = (currentPlayer == 'X') ? 'O' : 'X';
	            }
	        }
	    }

	    static void resetBoard() {
	        for (int i = 0; i < 3; i++)
	            for (int j = 0; j < 3; j++)
	                board[i][j] = ' ';
	    }

	    static void printBoard() {
	        System.out.println("Board:");
	        for (int i = 0; i < 3; i++) {
	            System.out.print(" ");
	            for (int j = 0; j < 3; j++) {
	                System.out.print(board[i][j]);
	                if (j < 2) System.out.print(" | ");
	            }
	            System.out.println();
	            if (i < 2) System.out.println("---+---+---");
	        }
	    }

	    static boolean checkWin(char player) {
	        // Check rows and columns
	        for (int i = 0; i < 3; i++)
	            if ((board[i][0] == player && board[i][1] == player && board[i][2] == player) ||
	                (board[0][i] == player && board[1][i] == player && board[2][i] == player))
	                return true;

	        // Check diagonals
	        return (board[0][0] == player && board[1][1] == player && board[2][2] == player) ||
	               (board[0][2] == player && board[1][1] == player && board[2][0] == player);
	    }
	}


